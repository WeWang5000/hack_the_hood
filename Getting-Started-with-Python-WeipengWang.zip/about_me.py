full_name = 'William Weipeng Wang'
favorite_nickname = 'k'
age = 21
python_experience = True

favorite_hobbies = [
  'boxing', 'day game', 'reading book', 'selfdevelopment'
]

favorite_thing = {
  'country' : 'ecuode',
  'food' : 'meat',
  'hobby': favorite_hobbies[1],
  'reading book' : 'steve job'
}

print(full_name, favorite_nickname, '\n', age, python_experience)

all_vars = dict(vars())